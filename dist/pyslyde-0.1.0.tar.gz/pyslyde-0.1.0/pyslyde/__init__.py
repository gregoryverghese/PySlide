from pyslide.slide import Slide, Annotations
from pyslide.slide_parser import WSIParser, Stitching

from pyslide import slide



